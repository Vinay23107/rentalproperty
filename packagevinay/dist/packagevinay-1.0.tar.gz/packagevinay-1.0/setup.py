from setuptools import setup
setup(name="packagevinay",
      version="1.0",
      description="Vinay Package",
      author="Vinay",
      packages=['packagevinay'],
      install_requires=['pgeocode'])